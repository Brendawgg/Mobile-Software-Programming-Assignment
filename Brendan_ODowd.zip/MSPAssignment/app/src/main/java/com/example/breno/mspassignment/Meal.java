package com.example.breno.mspassignment;

public class Meal {
    private String name;
    private String duration;
    private String difficulty;
    private String description;
    private int iconID;

    public Meal(String name, String duration, String difficulty, String description, int iconID) {
        super();
        this.name = name;
        this.duration = duration;
        this.difficulty = difficulty;
        this.description = description;
        this.iconID = iconID;
    }

    public String getName() {
        return name;
    }
    public String getDuration() {
        return duration;

    }
    public String getDifficulty() {
        return difficulty;
    }
    public String getDescription() {
        return description;
    }
    public int getIconID() {
        return iconID;
    }

}
