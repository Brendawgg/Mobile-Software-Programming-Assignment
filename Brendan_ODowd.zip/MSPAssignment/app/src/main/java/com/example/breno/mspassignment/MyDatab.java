package com.example.breno.mspassignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatab {


    // database columns
    private static final String KEY_ROWID 	    = "_id";
    private static final String KEY_USERNAME 	= "user_name";
    private static final String KEY_PASSWORD 	= "password";
    private static final String KEY_EMAIL 	    = "email";
    private static final String DATABASE_NAME 	= "User";
    private static final String DATABASE_TABLE 	= "UserDetails";
    private static final int DATABASE_VERSION 	= 1;

    // SQL statement to create the database
    private static final String DATABASE_CREATE =
            "create table UserDetails(_id integer primary key autoincrement, " +
                    "user_name text not null, " +
                    "password text not null, "  +
                    "email text not null);";

    private final Context context;
    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    // Constructor
    public MyDatab(Context ctx)
    {
        //
        this.context 	= ctx;
        DBHelper 		= new DatabaseHelper(context);
    }

    public MyDatab open() throws SQLException
    {
        db     = DBHelper.getWritableDatabase();
        return this;
    }

    // nested dB helper class
    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        //
        DatabaseHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }


        @Override
        //
        public void onCreate(SQLiteDatabase db)
        {

            db.execSQL(DATABASE_CREATE);
        }

        @Override
        //
        public void onUpgrade(SQLiteDatabase db, int oldVersion,
                              int newVersion)
        {
            db.execSQL("drop table if exists UserDetails");

        }


    }   // end nested class



    // remainder of the Database Example methods to "use" the database
    public void close()
    {

        DBHelper.close();
    }

    public Boolean insert(String user_name, String password)
    {
        SQLiteDatabase db     = DBHelper.getWritableDatabase();

        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_USERNAME, user_name);
        initialValues.put(KEY_PASSWORD, password);
        //initialValues.put(KEY_EMAIL, email);
        long ins = db.insert(DATABASE_TABLE, null, initialValues);

        if (ins == 1) {
            return false;
        }else return true;
    }

    //Checking if username exists
    public boolean checkUserName(String user_name) {
        SQLiteDatabase db = DBHelper.getReadableDatabase();

        Cursor myCursor = db.rawQuery("SELECT * FROM userDetails WHERE  user_name=?", new String[] {user_name});

        if (myCursor.getCount() > 0) return false;
        else return true;
    }



    public Cursor getPerson(long rowId) throws SQLException
    {
        Cursor myCursor =
                db.query(true, DATABASE_TABLE, new String[]
                                {
                                        KEY_ROWID,
                                        KEY_USERNAME,
                                        KEY_PASSWORD,
                                        KEY_EMAIL
                                },
                        KEY_ROWID + "=" + rowId,  null, null, null, null, null);

        if (myCursor != null)
        {
            myCursor.moveToFirst();
        }
        return myCursor;
    }

    public boolean updatePerson(long rowId, String username, String password, String email)
    {
        ContentValues args = new ContentValues();
        args.put(KEY_USERNAME, username);
        args.put(KEY_PASSWORD, password);
        args.put(KEY_EMAIL, email);
        return db.update(DATABASE_TABLE, args,
                KEY_ROWID + "=" + rowId, null) > 0;
    }
}
