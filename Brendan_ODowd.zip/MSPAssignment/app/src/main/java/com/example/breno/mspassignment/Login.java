package com.example.breno.mspassignment;

        import android.database.Cursor;
        import android.app.Activity;
        import android.content.Intent;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

public class Login extends Activity {
     /*
     * Called when the activity is first created.
     */

     EditText nameP, loginPass;
     Button toLogin, toRegister;
    com.example.breno.mspassignment.MyDatab db;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nameP = (EditText)findViewById(R.id.nameP);
        loginPass = (EditText)findViewById(R.id.loginPass);
        toLogin = (Button)findViewById(R.id.loginBtn);

        db = new com.example.breno.mspassignment.MyDatab(this);

        db.open();

        // Cursor c = db.getPerson(0);
        // Log.i("test", "number of rows returned are" + c.getCount());

        // db.close();

        Button loginBtn = (Button) findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String s1 = nameP.getText().toString();
                String s2 = loginPass.getText().toString();

                if (s1.equals("")||s2.equals("")) {
                    Toast.makeText(getApplicationContext(), "Feilds are Empty !", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    Intent intent = new Intent(Login.this, Welcome.class);
                    startActivity(intent);

                    Toast.makeText(getApplicationContext(), "Welcome Back !", Toast.LENGTH_SHORT).show();
                }
            }

        });


        Button toRegister = (Button) findViewById(R.id.registerBtn);
        toRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent2 = new Intent(Login.this, Register.class);
                startActivity(intent2);
            }

        });
    }
}