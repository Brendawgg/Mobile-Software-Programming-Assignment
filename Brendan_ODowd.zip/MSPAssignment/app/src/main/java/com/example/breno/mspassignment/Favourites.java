package com.example.breno.mspassignment;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.IOException;

public class Favourites extends Activity {

    public void getPhoto() {

        Intent openImg = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(openImg, 1);
    }

    public void getPhoto2() {

        Intent openImg = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(openImg, 2);
    }

    public void getPhoto3() {

        Intent openImg = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(openImg, 3);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                getPhoto();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
        else {
            getPhoto();
        }

        ImageButton favMeal = (ImageButton) findViewById(R.id.MyFImage);
        favMeal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                getPhoto();
            }

        });

        ImageButton favMeal2 = (ImageButton) findViewById(R.id.MyFImage1);
        favMeal2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                getPhoto2();
            }

        });

        ImageButton favMeal3 = (ImageButton) findViewById(R.id.MyFImage2);
        favMeal3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                getPhoto3();
            }

        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {

            Uri selectedImage = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);

                ImageView ourImage = (ImageView) findViewById(R.id.MyFImage);
                ourImage.setImageBitmap(bitmap);

            } catch (IOException e) {

                e.printStackTrace();
            }
        }

        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {

            Uri selectedImage = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);

                ImageView ourImage1 = (ImageView) findViewById(R.id.MyFImage1);
                ourImage1.setImageBitmap(bitmap);

            } catch (IOException e) {

                e.printStackTrace();
            }
        }

        if (requestCode == 3 && resultCode == RESULT_OK && data != null) {

            Uri selectedImage = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);

                ImageView ourImage2 = (ImageView) findViewById(R.id.MyFImage2);
                ourImage2.setImageBitmap(bitmap);

            } catch (IOException e) {

                e.printStackTrace();
            }
        }
    }
}
