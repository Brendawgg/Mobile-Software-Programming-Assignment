package com.example.breno.mspassignment;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class mealList extends Activity
{
    private List<Meal> myMeals = new ArrayList<Meal>();

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_list);

        populateMeaList();
        populateListView();
    }

    private void populateMeaList() {
        myMeals.add(new Meal("Spaghetti", "20 minutes", "Difficulty: 2", "Al Dante italian spaghetti with parseman sprinkle", R.drawable.souppic));
        myMeals.add(new Meal("Beef Steak", "40 minutes", "Difficulty: 4", "Tender sirloin prime irish beef steak with rosemary garanish", R.drawable.beef_pic));
        myMeals.add(new Meal("Grilled Salmon", "30 minutes", "Difficulty: 3", "Flaky grilled salmon drizzled with lemon zest", R.drawable.fish_pic));
        myMeals.add(new Meal("Pizza", "25 minutes", "Difficulty: 1", "Classic Pepperoni family pizza", R.drawable.pancake_pic));
        myMeals.add(new Meal("Pancakes", "15 minutes", "Difficulty: 2", "Delicious Maple syrup topped pancakes with berries", R.drawable.pancake_pic));
        myMeals.add(new Meal("Roast Lamb", "80 minutes", "Difficulty: 5", "Succulent slow roast lamb with seasonal veg", R.drawable.fish_pic));
        myMeals.add(new Meal("Vegetable Soup", "20 minutes", "Difficulty: 2", "Heatwarming homemade vegetable soup that hits home", R.drawable.souppic));
    }

    private void populateListView() {
        ArrayAdapter<Meal> myAdapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.outerMealListV);
        list.setAdapter(myAdapter);
    }

    // custom adapter class, declared as an inner class
    private class MyListAdapter extends ArrayAdapter<Meal>
    {
        // constructor
        public MyListAdapter()
        {
            super(mealList.this, R.layout.row, myMeals);
        }

        // This getview method is called each time a row needs to be formatted for the list
        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            View itemView = convertView;

            if (itemView == null) {

                itemView = getLayoutInflater().inflate(R.layout.row, parent, false);
            }
                //Find the Meal
                Meal currentMeal = myMeals.get(position);

                //Find the View
                ImageView myImage = (ImageView) itemView.findViewById(R.id.mImage);
                myImage.setImageResource(currentMeal.getIconID());

                TextView makeText = (TextView) itemView.findViewById(R.id.Mname);
                makeText.setText(currentMeal.getName());

                TextView makeTime = (TextView) itemView.findViewById(R.id.cTime);
                makeTime.setText(currentMeal.getDuration());

                TextView makeDiff = (TextView) itemView.findViewById(R.id.mDiff);
                makeDiff.setText(currentMeal.getDifficulty());

                TextView makeDesc = (TextView) itemView.findViewById(R.id.mDesc);
                makeDesc.setText(currentMeal.getDescription());

                return itemView;
            }
    }
}