package com.example.breno.mspassignment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

public class Calander extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calander);

        Button toDaily = (Button) findViewById(R.id.dailyBtn);
        toDaily.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent toDay = new Intent(Calander.this, Daily.class);
                startActivity(toDay);
            }
        }
        );
    }
}
