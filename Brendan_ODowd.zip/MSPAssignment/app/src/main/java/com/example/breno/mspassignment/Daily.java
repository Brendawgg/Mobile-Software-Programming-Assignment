package com.example.breno.mspassignment;

import android.app.Activity;
import android.os.Bundle;

public class Daily extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily);
    }
}
