package com.example.breno.mspassignment;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends Activity {

    com.example.breno.mspassignment.MyDatab db;

    EditText nameP, Pass, cPass;
    Button toRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new com.example.breno.mspassignment.MyDatab(this);


        nameP = (EditText)findViewById(R.id.username);
        Pass = (EditText)findViewById(R.id.password);
        cPass = (EditText)findViewById(R.id.cPassword);
        toRegister = (Button)findViewById(R.id.registerBtn);

        Button toRegister = (Button) findViewById(R.id.email_register_button);
        toRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String s1 = nameP.getText().toString();
                String s2 = Pass.getText().toString();
                String s3 = cPass.getText().toString();

                if (s1.equals("")||s2.equals("")) {
                    Toast.makeText(getApplicationContext(), "Feilds are Empty !", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(s2.equals(s3)) {
                        boolean checkUserName = db.checkUserName(s1);
                        if(checkUserName == true) {
                            boolean insert = db.insert(s1, s2);
                            if (insert == true) {

                                Toast.makeText(getApplicationContext(), "Registered Succesfuly", Toast.LENGTH_SHORT).show();

                                Intent registerToWelcome = new Intent(Register.this, Welcome.class);
                                startActivity(registerToWelcome);
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Email Already Exists..", Toast.LENGTH_SHORT).show();
                    }

                    }
                }
            }
        });
    }
}