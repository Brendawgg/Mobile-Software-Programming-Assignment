package com.example.breno.mspassignment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Welcome extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        ImageButton UserDetails = (ImageButton) findViewById(R.id.userimg);
        UserDetails.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent3 = new Intent(Welcome.this, Udetails.class);
                startActivity(intent3);
            }

        });

        ImageButton MealsBtn = (ImageButton)findViewById(R.id.mealspic);
        MealsBtn.setOnClickListener(new View.OnClickListener() {
             public void onClick(View v) {
                 Intent welcomeToMealList = new Intent(Welcome.this, mealList.class);
                 startActivity(welcomeToMealList);
             }
        });

        ImageButton Cdar = (ImageButton)findViewById(R.id.clndrimg);
        Cdar.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent welcomeToCalander = new Intent(Welcome.this, Calander.class);
                    startActivity(welcomeToCalander);
                }

        });

        ImageButton Favs = (ImageButton)findViewById(R.id.favfoods);
        Favs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent welcomeToFavs = new Intent(Welcome.this, Favourites.class);
                startActivity(welcomeToFavs);
            }

        });

        ImageButton Locs = (ImageButton)findViewById(R.id.locBtn);
        Locs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent welcomeToLocs = new Intent(Welcome.this, Locations.class);
                startActivity(welcomeToLocs);
            }

        });
    }
}
